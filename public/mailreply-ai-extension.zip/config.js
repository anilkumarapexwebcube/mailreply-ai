// Single place to change the MailReply AI backend origin.
const MAILREPLY_API_BASE = "https://project--3e258928-9668-4bbe-9523-fb530a152290.lovable.app";
