// Single place to change the MailReply AI backend origin.
const MAILREPLY_API_BASE = "https://mailreplyai.vercel.app";
